#!/bin/sh

autoheader
autoconf
./configure
